#include "Neptunium_oneHeader.hpp"

int main(void) {

    Np::RenderHandler renderHandler("ExampleWindow", {1600, 900}, false, 60);

    Texture2D test = LoadTexture("assets/testimg.png");

    while (!(renderHandler.windowShouldClose()))
    {

        if (IsKeyPressed(KEY_SPACE))
            renderHandler.toggleFullscreen();

        renderHandler.renderTexture(test, {0, 0});

        wrapRaylibRenderFunction(renderHandler, DrawText("Test\nabcdefghijklmnopqrstuvwxyz\nABCDEFGHIJKLMNOPQRSTUVWXYZ\näöüßÄÖÜ", 10, 50, 100, RED));

        renderHandler.updateScreen();

    }

    CloseWindow();

    return 0;
}