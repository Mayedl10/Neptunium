$ScriptPath = $MyInvocation.MyCommand.Path
$ScriptDirectory = Split-Path $ScriptPath
# Change the working directory to the script's directory
Set-Location -Path $ScriptDirectory

g++ src/*.cpp compile_assets/resource.o -Iinclude -L. -lneptunium -o main.exe -mwindows

# if you don't want the neptunium image, remove "compile_assets/resource.o" and " -mwindows"

if ($lastExitCode -eq 0) {
    Start-Process main.exe
}